<?php
namespace Model;
use Illuminate\Database\Eloquent\Model as Eloquent;
class Shifts extends Eloquent {
	protected $primaryKey = 'Id';
	public $timestamps = false;
}
?>