<?php
define('MAIN_PATH', dirname($_SERVER["SCRIPT_NAME"]));
define('ADMIN_ROLE', 1);
define('EMPLOYEE_ROLE', 2);
define('VIEW_FOLDER', MAIN_PATH.'/views/');
?>